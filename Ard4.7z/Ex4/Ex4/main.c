#include <avr/io.h>
#include <avr/interrupt.h>
#define LED PB5
void fSClkPrescaler() {
	cli(); // Clear global intr flag
	CLKPR = 0b10000000; // Enable CLKPR change
	CLKPR = 0b00000100; // Set System Clock Prescaler
}
void fInitTimer() {
	fSClkPrescaler();
	TCCR0A |= (1<<WGM00); // Set Timer0 to phase correct mode
	TCCR0A |= (1<<COM0A1); // Non-inverting mode for OC0A
	TCCR0A |= (1<<COM0B1)|(1<<COM0B0); // Inverting mode for OC0B
	OCR0A = 50;
	OCR0B = 50;
	TCCR0B |= (1<<CS02)|(1<<CS00); // Timer0 Clock=ClockIO/1024
}
int main(void) {
	DDRB |= _BV(LED); // Set PB5 as output
	PORTB &= ~_BV(LED); // Turn off LED
	DDRD |= _BV(PD6)|_BV(PD5); // Set PD6 and PD5 as output
	DDRD &= ~_BV(PD2); // Set PD2 as input
	EICRA |= _BV(ISC01); // Falling edge interrupt for INT0
	EIMSK |= _BV(INT0);
	fInitTimer(); // Configure Timer0
	sei(); // Enable global interrupts
	while (1) {}
}
ISR(INT0_vect) {
	PORTB ^= _BV(LED); // Toggle LED
}