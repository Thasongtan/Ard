#include <avr/io.h>
#include <avr/interrupt.h>
#define LED1 PB6
#define LED2 PB5
void fSClkPrescaler() {
	cli(); // Clear global intr flag
	CLKPR = 0b10000000; // Enable CLKPR change
	CLKPR = 0b00000111; // Set System Clock Prescaler
}
void fInitTimer() {
	fSClkPrescaler();
	TCCR0A |= (1<<WGM01)|(1<<WGM00); // Set Timer0 to Fast mode
	TCCR0A |= (1<<COM0A1); // Non-inverting mode for OC0A
	TCCR0A |= (1<<COM0B1)|(1<<COM0B0);
	OCR0A = 128; // Set On period
	OCR0B = 128;
	TCCR0B |= (1<<CS02)|(1<<CS00); // Timer0 Clock=ClockIO / 1024
}
int main(void) {
	DDRB |= _BV(LED2)|_BV(LED1); // Set PB5 as output
	PORTB &=  _BV(LED1);
	DDRD |= _BV(PD6)|_BV(PD5); // Set PD6 as output
	fInitTimer(); // Configure Timer0
	while (1) {}
}